import { navbar } from "../components/navbar"

import "../styles/navbar.css"
console.log("ansdbs",navbar)
let navbar_div=document.getElementById("navbar")
navbar_div.innerHTML=navbar()//we got out data in webpage

