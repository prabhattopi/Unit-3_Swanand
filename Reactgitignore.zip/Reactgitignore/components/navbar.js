function navbar(){
    return `
    <h3><a href="index.html">HOme</a></h3>
    </div>
    <div id="options">
        <h3>
            <a href="jewellery.html">jewellery</a>
        </h3>
        <h3>
            <a href="electronic.html">Electronic</a>
        </h3>
        <h3>
            <a href="login.html">Login</a>
        </h3>
        <h3>
            <a href="signup.html">signup</a>
        </h3>
            
       
    </div>
    `
}

export { navbar } ;
